﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hunter
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Animal[] allatok=new Animal[10];
            allatok[0]=new Rabbit();
            allatok[1] = new PolarBear();
            allatok[2] = new Squirrel();
//------------------------------------------
        //Új adatok (prémek)
            allatok[3] = new Squirrel();
            allatok[4] = new PolarBear();
            allatok[5] = new Rabbit();
            allatok[6] = new PolarBear();

            for (int i = 0; i < allatok.Length; i++)
            {
                Console.WriteLine(allatok[i].getType() + " " + allatok[i].getPrice()+"\n");
            }
            
            
        
        }
    }
}
