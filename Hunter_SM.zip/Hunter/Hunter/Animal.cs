﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hunter
{
    abstract class Animal
    {
        const int basePrice = 100000;
        const string type = "";

        public virtual double getPrice()
        {
            return basePrice;
        }

        public virtual string getType()
        {
            return "A "+type+" prémje: ";
        }
        
        

    }
}
