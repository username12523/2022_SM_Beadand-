﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFurniture
{
    internal class Chair : Furniture
    {
        const double chairFactor = 1.2;
        const string type = "Chair";
        const string id = "LA73G";
        const int labszam = 4;

        public override double getPrice()
        {
            return base.getPrice() * chairFactor;
        }

        public override string getType()
        {
            return type;
        }

        public override string getId()
        {
            return id;
        }

        public override int getLabszam()
        {
            return labszam;
        }

    }
}
