﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFurniture
{
    internal class Bed : Furniture
    {
        const double bedFactor = 2.4;
        const string type = "Bed";
        const string id = "9HAZ3";
        const int hossz = 210;
        const int szelesseg = 120;

        public override double getPrice()
        {
            return base.getPrice() * bedFactor;
        }

        public override string getType()
        {
            return type;
        }

         public override string getId()
        {
            return id;
        }

        public override int getHossz()
        {
            return hossz;
        }


        public override int getSzelesseg()
        {
            return szelesseg;
        }



    }
}
