﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFurniture
{
    internal class Furniture
    {
        const int basePrice = 25000;
        const string type = "";
        const string id= "";
        const int hossz = 0;
        const int magassag = 0;
        const int szelesseg = 0;
        const int labszam = 0;
        
        public virtual double getPrice()
        {
            return basePrice;
        }

        public virtual string getType()
        {
            return  type;
        }

        //asztal
        public virtual int getMagassag()
        {
            return magassag;
        }

        //ágy
        public virtual int getHossz()
        {
            return hossz;
        }

        //ágy
        public virtual int getSzelesseg()
        {
            return szelesseg;
        }

        //szék
        public virtual int getLabszam()
        {
            return labszam;
        }

        public virtual string getId()
        {
            return id;
        }

    }
}
