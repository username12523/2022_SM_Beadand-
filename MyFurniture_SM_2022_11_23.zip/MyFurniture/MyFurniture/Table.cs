﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFurniture
{
    internal class Table : Furniture
    {
        const double tableFactor = 0.3;
        const string type = "Table";
        const string id = "13IE3";
        const int magassag = 60;

        public override double getPrice()
        {
            return base.getPrice() * tableFactor;
        }

        public override string getType()
        {
            return type;
        }

        public override string getId()
        {
            return id;
        }

        public override int getMagassag()
        {
            return magassag;
        }

    }
}
