﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFurniture
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Furniture[] furnitures= new Furniture[3];
            furnitures[0] = new Table();
            furnitures[1] = new Bed();
            furnitures[2] = new Chair();

            for (int i = 0; i < furnitures.Length; i++)
            {
                

                Console.WriteLine(
                    "\n Bútor Id: " + furnitures[i].getId() +
                    "\n Bútor típusa: " + furnitures[i].getType() +
                    "\n Bútor konstansszorosa: " + furnitures[i].getPrice()); 
                   
                if (furnitures[i].getMagassag() == 0)
                {
                    Console.Write("");
                }
                else
                {
                    Console.WriteLine(" Bútor Magasság: " + furnitures[i].getMagassag()+"cm");
                }
                //-------------------------------------------------------------------------------------
                if (furnitures[i].getHossz() == 0)
                {
                    Console.Write("");
                }
                else
                {
                    Console.WriteLine(" Bútor hossza: " + furnitures[i].getHossz() + "cm");
                }
                //-------------------------------------------------------------------------------------
                if (furnitures[i].getSzelesseg() == 0)
                {
                    Console.Write("");
                }
                else
                {
                    Console.WriteLine(" Bútor szélessége " + furnitures[i].getSzelesseg() + "cm");
                }
                //-------------------------------------------------------------------------------------
                if (furnitures[i].getLabszam() == 0)
                {
                    Console.Write("");
                }
                else
                {
                    Console.Write(" Bútor lábszáma: " + furnitures[i].getLabszam() + "cm");
                }
                
            }


            Console.ReadKey();
        }
    }
}
