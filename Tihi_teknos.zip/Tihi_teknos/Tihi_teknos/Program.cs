﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tihi_teknos
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Food[] foods = new Food[3];
            foods[0] = new Crab();
            foods[1] = new Salad();
            foods[2] = new Turtle();

            for (int i = 0; i < foods.Length; i++)
            {
                Console.WriteLine(foods[i].getFoodType() + " tápértéke: " + foods[i].getValue());
            }

            for (int i = 0; i < 1; i++)
            {
                Console.WriteLine("\nTihi éhség szintje: " + foods[i].turtleFedLevel());
                Console.WriteLine("Tihi boldogság szinje: " + foods[i].turtleHappiness());
            }
        }
    }
}
