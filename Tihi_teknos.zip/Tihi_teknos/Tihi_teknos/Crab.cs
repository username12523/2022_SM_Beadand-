﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tihi_teknos
{
    internal class Crab : Food
    {
        const int tapertek = 10;
        const string etel = "Crab";

        public override int getValue()
        {
            return base.getValue() * tapertek;
        }

        public override string getFoodType()
        {
            return etel;
        }
    }
}
