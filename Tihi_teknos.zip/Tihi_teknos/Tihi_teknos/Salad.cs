﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tihi_teknos
{
    internal class Salad : Food
    {
        const int tapertek = 10;
        const string etel = "Salad";

        public override int getValue()
        {
            return tapertek;
        }

        public override string getFoodType()
        {
            return etel;
        }

    }
}
