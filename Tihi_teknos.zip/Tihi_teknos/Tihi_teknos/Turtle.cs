﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tihi_teknos
{
    internal class Turtle : Food
    {
        const int happiness = 0;
        const int fedLevel = 0;


        public virtual int eatFood()
        {
            return base.getValue();
        }

        public override int turtleFedLevel()
        {
            return fedLevel;
        }

        public override int turtleHappiness()
        {
            return happiness;
        }

    }
}
