﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tihi_teknos
{
    internal class Food
    {
        const int meret = 3;
        const string etel = "";
        const int fedLevel = 0;
        const int happiness = 0;

        public virtual int getValue()
        {
            return meret;
        }

        public virtual string getFoodType()
        {
            return etel;
        }

        public virtual int turtleFedLevel()
        {
            return fedLevel;
        }

        public virtual int turtleHappiness()
        {
            return happiness;
        }
    }
}
